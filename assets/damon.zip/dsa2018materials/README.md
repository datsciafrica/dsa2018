# dsa2018materials
Data Science Africa Nyeri 2018 lab materials
